﻿package wall_e;

import java.awt.Color;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import robocode.*;
import robocode.util.Utils;

public class wall_e extends AdvancedRobot {

    private static final int WALL = 80;
    private static final int CORNER = 100;
    private static final double PRECISAO_TIRO = 240;
    private static final double REGULADOR_BULLETPOWER = 400;
    private static final double LONGE = 200;
    private static final double PERTO = 80;
    private static final double MUITO = 30;
    private static final double POUCO = 15;
    private static final double RECENTE = 3;
    private static final int TEMPO_EXCLUSAO_INIMIGO = 18;
    private static final int TEMPO_STRAFING = 8;
    private static final int TEMPO_TOLERANCIA_INVERSAO = 6;
    private static final int TEMPO_TOLERANCIA_INVERSAO_CRITICO = 5;
    private static final double LONGE_PARA_DESVIAR = 240;

    private Enemy enemy;
    private ArrayList<Enemy> enemies;

    private int direcao;
    private int direcaoRadar;
    private boolean inWall;
    private long inverteu;
    private long virou;

    @Override
    public void run() {
        inicializar();

        while (true) {
            removerInimigosAntigos();
            moverRadar();
            verificarColisoesComParede();

            if (enemy.existe() && (getTime() - enemy.getLastUpdate()) < TEMPO_EXCLUSAO_INIMIGO) {
                if ((getTime() - enemy.getLastUpdate()) < RECENTE) {
                    atirar();
                    mover();
                }
            } else {
                enemy.finish();
            }

            execute();
        }
    }

    public void inicializar() {
        enemy = new Enemy();
        enemies = new ArrayList<>();

        setRadarColor(Color.RED);
        setGunColor(Color.YELLOW);
        setBodyColor(Color.WHITE);
        setBulletColor(Color.YELLOW);
        setScanColor(Color.RED);

        setAdjustGunForRobotTurn(true);
        setAdjustRadarForGunTurn(true);
        setAdjustRadarForRobotTurn(true);

        inWall = (getX() <= 50 || getY() <= 50 || getBattleFieldWidth() - getX() <= 50 || getBattleFieldHeight() - getY() <= 50);

        direcao = 1;
        direcaoRadar = 1;
        inverteu = 0;
        virou = 0;

        setAhead(Double.POSITIVE_INFINITY * direcao);
    }

    public void mover() {
        double angulo = enemy.getBearing() + 90 - (enemy.getDistance() > LONGE ? MUITO : (enemy.getDistance() < PERTO ? -MUITO : POUCO)) * direcao;

        setAhead(Double.POSITIVE_INFINITY * direcao);
        setTurnRight(normalizeBearing(angulo));

        inverteu++;
        virou++;

        if (virou > TEMPO_STRAFING && inverteu > TEMPO_TOLERANCIA_INVERSAO) {
            reverseDirection();
            virou = 0;
        }
    }

    public void atirar() {
        if (enemy.existe()) {
            double firepower = forcaDoTiro();
            double eAbsBearing = getHeadingRadians() + Math.toRadians(enemy.getBearing());
            double bV = Rules.getBulletSpeed(firepower);
            double eX = getX() + enemy.getDistance() * Math.sin(eAbsBearing);
            double eY = getY() + enemy.getDistance() * Math.cos(eAbsBearing);
            double eV = enemy.getVelocity();
            double eHd = Math.toRadians(enemy.getHeading());

            double A = (eX - getX()) / bV;
            double B = eV / bV * Math.sin(eHd);
            double C = (eY - getY()) / bV;
            double D = eV / bV * Math.cos(eHd);
            double a = A * A + C * C;
            double b = 2 * (A * B + C * D);
            double c = (B * B + D * D - 1);
            double discrim = b * b - 4 * a * c;

            if (discrim >= 0) {
                double t1 = 2 * a / (-b - Math.sqrt(discrim));
                double t2 = 2 * a / (-b + Math.sqrt(discrim));
                double t = Math.min(t1, t2) >= 0 ? Math.min(t1, t2) : Math.max(t1, t2);
                double endX = limit(eX + eV * t * Math.sin(eHd), 16 / 2, getBattleFieldWidth() - 16 / 2);
                double endY = limit(eY + eV * t * Math.cos(eHd), 16 / 2, getBattleFieldHeight() - 16 / 2);

                double anguloDeAjuste = Utils.normalRelativeAngle(Math.atan2(endX - getX(), endY - getY()) - getGunHeadingRadians());

                if (valeAPenaAtirar(anguloDeAjuste)) {
                    turnGunRightRadians(anguloDeAjuste);
                    fire(firepower);
                } else {
                    turnGunRightRadians(anguloDeAjuste);
                }
            }
        }
    }

    public void moveRadar() {
        if (enemy.existe() && (getTime() - enemy.getLastUpdate()) < RECENTE && getOthers() == 1) {
            double turn = getHeading() - getRadarHeading() + enemy.getBearing();
            turn += 30 * direcaoRadar;
            setTurnRadarRight(normalizeBearing(turn));
            direcaoRadar *= -1;
        } else {
            setTurnRadarRight(Double.POSITIVE_INFINITY);
        }
    }

    @Override
    public void onScannedRobot(ScannedRobotEvent e) {
        adicionarInimigos(e);

        if (!(enemy.existe() && !enemy.getName().equals(e.getName()))) {
            if (enemy.getEnergy() > e.getEnergy() && (getTime() - enemy.getLastUpdate()) < RECENTE && inverteu > TEMPO_TOLERANCIA_INVERSAO_CRITICO && e.getDistance() > LONGE_PARA_DESVIAR) {
                reverseDirection();
                virou = 0;
            }
            enemy.update(e);
        }
    }

    @Override
    public void onHitByBullet(HitByBulletEvent e) {
        if (inverteu > TEMPO_TOLERANCIA_INVERSAO) {
            reverseDirection();
        }
    }

    @Override
    public void onHitRobot(HitRobotEvent e) {
        if (e.isMyFault()) {
            reverseDirection();
        }
    }

    @Override
    public void onBulletHit(BulletHitEvent e) {
        if (e.getEnergy() == 0) {
            enemy.finish();
        }
    }

    @Override
    public void onHitWall(HitWallEvent e) {
        reverseDirection();
    }

    private double forcaDoTiro() {
        return Math.min(REGULADOR_BULLETPOWER / enemy.getDistance(), Math.min(3.0, getEnergy()));
    }

    private boolean valeAPenaAtirar(double angle) {
        double anguloRelativo = Math.toDegrees(Math.atan(Math.abs(enemy.getX() - getX()) / Math.abs(enemy.getY() - getY())));
        double anguloAbsolutoFinal = getGunHeading() + angle;

        double theta = Math.abs(anguloRelativo - anguloAbsolutoFinal);
        theta = theta % 90;

        return (Math.tan(Math.toRadians(theta)) * enemy.getDistance() < PRECISAO_TIRO);
    }

    private void removerInimigosAntigos() {
        enemies.removeIf(e -> getTime() - e.getLastUpdate() >= TEMPO_EXCLUSAO_INIMIGO);
    }

    private void adicionarInimigos(ScannedRobotEvent e) {
        for (Enemy en : enemies) {
            if (en.getName().equals(e.getName())) {
                return;
            }
        }
        enemies.add(new Enemy(e));
    }

    private void reverseDirection() {
        direcao *= -1;
        inverteu = 0;
        setAhead(Double.POSITIVE_INFINITY * direcao);
    }

    private double normalizeBearing(double angle) {
        return Utils.normalRelativeAngleDegrees(angle);
    }

    private void verificarColisoesComParede() {
        if ((getX() <= WALL && direcao == -1) || (getY() <= WALL && direcao == -1) ||
                (getBattleFieldWidth() - getX() <= WALL && direcao == 1) ||
                (getBattleFieldHeight() - getY() <= WALL && direcao == 1)) {
            reverseDirection();
        }
    }

    private double limit(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
