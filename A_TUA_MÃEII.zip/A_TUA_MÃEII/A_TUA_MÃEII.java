package A_TUA_MÃEII;

import robocode.*;
import robocode.util.Utils;
import java.awt.geom.Point2D;

public class A_TUA_MÃEII extends AdvancedRobot {

    @Override
    public void run() {
        // Configuração inicial do radar e canhão
        setAdjustRadarForRobotTurn(true);
        setAdjustGunForRobotTurn(true);
        setAdjustRadarForGunTurn(true);
        turnRadarRightRadians(Double.POSITIVE_INFINITY);

        while (true) {
            executarMovimentoOscilante();
            scan(); // Continuar escaneando para detectar robôs
        }
    }

    public void onScannedRobot(ScannedRobotEvent e) {
        executarMovimentoOscilante(); // Mantém o movimento enquanto mira

        // Lógica de ajuste do radar para ficar "travado" no inimigo
        double radarTurn = getHeadingRadians() + e.getBearingRadians() - getRadarHeadingRadians();
        setTurnRadarRightRadians(Utils.normalRelativeAngle(radarTurn));

        // Lógica de mira preditiva
        double bulletPower = calcularForcaDoTiro(e.getDistance());
        double anguloDisparo = calcularAnguloDisparo(e, bulletPower);

        setTurnGunRightRadians(Utils.normalRelativeAngle(anguloDisparo - getGunHeadingRadians()));
        if (getGunHeat() == 0) {
            fire(bulletPower);
        }
    }

    @Override
    public void onHitByBullet(HitByBulletEvent e) {
        executarMovimentoOscilante();
    }

    @Override
    public void onHitWall(HitWallEvent e) {
        // Recuar e ajustar a direção ao atingir uma parede
        setBack(3000);
        setTurnRight(90);
        setAhead(2000);
    }

    private void executarMovimentoOscilante() {
        // Lógica de movimento oscilante (menos previsível que o movimento em círculos)
        setAhead(150 * (Math.random() * 2 + 1)); // Movimento para frente com variação aleatória
        setTurnRight(90 * Math.random()); // Vira em um ângulo aleatório
        setBack(100 * (Math.random() * 2 + 1)); // Movimento para trás com variação aleatória
        setTurnLeft(90 * Math.random()); // Vira em um ângulo aleatório
    }

    private double calcularForcaDoTiro(double distancia) {
        if (distancia > 200 || getEnergy() < 15) {
            return 1;
        } else if (distancia > 50) {
            return 2;
        } else {
            return 3;
        }
    }

    private double calcularAnguloDisparo(ScannedRobotEvent e, double bulletPower) {
        double meuX = getX();
        double meuY = getY();
        double anguloAbsoluto = getHeadingRadians() + e.getBearingRadians();
        double inimigoX = meuX + e.getDistance() * Math.sin(anguloAbsoluto);
        double inimigoY = meuY + e.getDistance() * Math.cos(anguloAbsoluto);
        double velocidadeInimigo = e.getVelocity();
        double headingInimigo = e.getHeadingRadians();

        double deltaTempo = 0;
        double campoBatalhaAltura = getBattleFieldHeight();
        double campoBatalhaLargura = getBattleFieldWidth();
        double inimigoPrevistoX = inimigoX, inimigoPrevistoY = inimigoY;

        while ((++deltaTempo) * (20.0 - 3.0 * bulletPower) < Point2D.Double.distance(meuX, meuY, inimigoPrevistoX, inimigoPrevistoY)) {
            inimigoPrevistoX += Math.sin(headingInimigo) * velocidadeInimigo;
            inimigoPrevistoY += Math.cos(headingInimigo) * velocidadeInimigo;

            // Limitar a posição prevista do inimigo dentro do campo de batalha
            if (inimigoPrevistoX < 18.0 || inimigoPrevistoY < 18.0 || inimigoPrevistoX > campoBatalhaLargura - 18.0 || inimigoPrevistoY > campoBatalhaAltura - 18.0) {
                inimigoPrevistoX = Math.min(Math.max(18.0, inimigoPrevistoX), campoBatalhaLargura - 18.0);
                inimigoPrevistoY = Math.min(Math.max(18.0, inimigoPrevistoY), campoBatalhaAltura - 18.0);
                break;
            }
        }

        return Math.atan2(inimigoPrevistoX - meuX, inimigoPrevistoY - meuY);
    }
}

